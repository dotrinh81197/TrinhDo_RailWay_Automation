# TrinhDo_RailWay_Automation
Chrome version:  91.0.4472.124 

Chrome driver version 91
